#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <sstream>
using namespace std;

struct node {
    string data;
    int weight_of_word;
    struct node* right;
    struct node* left;
};

struct node* node_creation(int w, string d) {
    struct node* temp = new node;
    temp->data = d;
    temp->weight_of_word = w;
    temp->left = nullptr;
    temp->right = nullptr;
    return temp;
}

void insert(struct node*& root, int key, string word) {
    if (root == nullptr) {
        root = node_creation(key, word);
        return;
    }

    if (root->weight_of_word < key) {
        insert(root->left, key, word);
    } else if (root->weight_of_word > key) {
        insert(root->right, key, word);
    }
}

void inorder_traversal(struct node* root, vector<string>& dictionary) {
    if (root == nullptr)
        return;

    inorder_traversal(root->left, dictionary);
    dictionary.push_back(root->data);
    inorder_traversal(root->right, dictionary);
}

int levenshteinDistance(const string& s1, const string& s2) {
    int m = s1.length();
    int n = s2.length();

    vector<vector<int>> dp(m + 1, vector<int>(n + 1, 0));

    for (int i = 0; i <= m; ++i) {
        for (int j = 0; j <= n; ++j) {
            if (i == 0)
                dp[i][j] = j;
            else if (j == 0)
                dp[i][j] = i;
            else if (s1[i - 1] == s2[j - 1])
                dp[i][j] = dp[i - 1][j - 1];
            else
                dp[i][j] = 1 + min({dp[i][j - 1], dp[i - 1][j], dp[i - 1][j - 1]});
        }
    }

    return dp[m][n];
}

void spell_corrector(struct node* root, const string& inputWord, vector<string>& suggestions) {
    if (root == nullptr)
        return;

    string dictionaryWord = root->data;
    if (dictionaryWord == inputWord) 
        return;

    if (abs((int)(dictionaryWord.size() - inputWord.size())) <= 2) {
        int distance = levenshteinDistance(dictionaryWord, inputWord);
        int hitrate = ((inputWord.size() - distance) * 100) / inputWord.size();
        if (hitrate >= 50) {
            suggestions.push_back(dictionaryWord);
        }
    }

    spell_corrector(root->left, inputWord, suggestions);
    spell_corrector(root->right, inputWord, suggestions);
}

string stemWord(const string& word) {
    string stem = word;
    if (stem.length() > 4) {
        if (stem.substr(stem.length() - 3) == "ing" && stem.length() > 5) {
            stem = stem.substr(0, stem.length() - 3);
        } else if (stem.substr(stem.length() - 2) == "ed" && stem.length() > 4) {
            stem = stem.substr(0, stem.length() - 2);
        }
    }
    return stem;
}

void search(struct node* root, const string& inputWord, vector<string>& dictionary, const string& filename) {
    if (root == nullptr) {
        cout << "Dictionary is empty.\n";
        return;
    }

    string stemmedWord = stemWord(inputWord);

    auto it = find(dictionary.begin(), dictionary.end(), stemmedWord);
    if (it != dictionary.end()) {
        cout << inputWord << " (" << stemmedWord << ") found in the dictionary.\n";
    } else {
        cout << inputWord << " (" << stemmedWord << ") doesn't seem to be correct. Suggestions:\n";

        vector<string> suggestions;
        for (const auto& word : dictionary) {
            if (levenshteinDistance(word, stemmedWord) <= 2) {
                suggestions.push_back(word);
            }
        }

        if (suggestions.empty()) {
            cout << "No suggestions found.\n";
        } else {
            for (const auto& suggestion : suggestions) {
                cout << suggestion << "\n";
            }
        }

        char choice;
        cout << "Do you want to add the word '" << stemmedWord << "' to the dictionary? (y/n): ";
        cin >> choice;
        if (choice == 'y' || choice == 'Y') {

            ofstream outFile(filename, ios::app);
            if (outFile.is_open()) {
                outFile << stemmedWord << endl;
                outFile.close();
            }

            insert(root, dictionary.size() + 1, stemmedWord);
            dictionary.push_back(stemmedWord);
            cout << stemmedWord << " has been added to the dictionary.\n";
        }
    }
}

int main() {
    struct node* root = nullptr;
    vector<string> dictionary;
    string filename = "C:\\Users\\Muzna\\c++\\c++codes\\spellchecker\\dict.txt";

    ifstream inFile(filename);
    if (inFile.is_open()) {
        string word;
        int weight = 1;
        while (getline(inFile, word)) {
            insert(root, weight++, word);
            dictionary.push_back(word);
        }
        inFile.close();
    } else {
        cout << "Unable to open file: " << filename << endl;
        return 1;
    }

    string inputSentence;
    cout << "Enter a sentence: ";
    getline(cin, inputSentence);

    stringstream ss(inputSentence);
    string word;
    vector<string> wordsToAdd;
    while (ss >> word) {
        search(root, word, dictionary, filename);
        string stemmedWord = stemWord(word);
        auto it = find(dictionary.begin(), dictionary.end(), stemmedWord);
        if (it == dictionary.end()) { 
            wordsToAdd.push_back(stemmedWord);
        }
    }

    if (!wordsToAdd.empty()) {
        cout << "The following words were not found in the dictionary:\n";
        for (const auto& word : wordsToAdd) {
            cout << word << endl;
        }
        char choice;
        cout << "Do you want to add these words to the dictionary? (y/n): ";
        cin >> choice;
        if (choice == 'y' || choice == 'Y') {
            ofstream outFile(filename, ios::app);
            if (outFile.is_open()) {
                for (const auto& word : wordsToAdd) {
                    outFile << word << endl;
                    insert(root, dictionary.size() + 1, word);
                    dictionary.push_back(word);
                }
                outFile.close();
                cout << "Words added to the dictionary.\n";
            } else {
                cout << "Unable to open file for writing.\n";
            }
        }
    }

    return 0;
}
