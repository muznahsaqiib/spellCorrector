import tkinter as tk
from tkinter import messagebox
from tkinter import scrolledtext
import subprocess

def spell_checker(input_sentence):
    try:
        result = subprocess.check_output(["C:\\Users\\Muzna\\c++\\c++codes\\spellchecker\\spellcorrector.exe"], input=input_sentence, text=True, stderr=subprocess.PIPE)
        suggestions = result.strip().split('\n')
        corrected_words = []
        for suggestion in suggestions:
            parts = suggestion.split(':')
            misspelled_word = parts[0]
            suggestion_str = ':'.join(parts[1:])
            corrected_words.append((misspelled_word, suggestion_str))
        return corrected_words
    except subprocess.CalledProcessError as e:
        return [("Error", e.stderr.strip())]

def evaluate_expression():
    input_sentence = sentence_text.get("1.0", tk.END).strip()
    suggestions = spell_checker(input_sentence)
    result = ""
    for suggestion in suggestions:
        if len(suggestion) == 1:
    
            result += f"{suggestion[0]} "
        else:
            misspelled_word, suggestion_str = suggestion
            if suggestion_str:
                result += f"{misspelled_word}\n{suggestion_str}\n"
            else:
                result += f"{misspelled_word}\n"
    suggestion_text.delete("1.0", tk.END)
    suggestion_text.insert(tk.END, result)

def add_to_dictionary():
    words = sentence_text.get("1.0", tk.END).split()  # Split the input sentence into individual words
    for word in words:
        try:
            with open("C:\\Users\\Muzna\\c++\\c++codes\\spellchecker\\dict.txt", "a+") as file:
                file.seek(0)
                dictionary = file.read().splitlines()
                if word not in dictionary:
                    confirm = messagebox.askyesno("Confirm", f"Add '{word}' to dictionary?")
                    if confirm:
                        file.write("\n" + word)
                        messagebox.showinfo("Info", f"'{word}' added to dictionary!")
                else:
                    messagebox.showinfo("Info", f"'{word}' is already in the dictionary!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to add '{word}' to dictionary: {str(e)}")

root = tk.Tk()
root.title("Spell Checker")
root.geometry("600x400")

frame = tk.Frame(root, bg="white")
frame.pack(padx=20, pady=20, fill="both", expand=True)

sentence_label = tk.Label(frame, text="Enter a sentence:", pady=5, bg="white", font=("Arial", 12), fg="black")
sentence_label.grid(row=0, column=0, sticky="w")

sentence_text = scrolledtext.ScrolledText(frame, width=40, height=5, wrap=tk.WORD, font=("Arial", 12))
sentence_text.grid(row=0, column=1)

suggestion_label = tk.Label(frame, text="Suggestions:", pady=5, bg="white", font=("Arial", 12), fg="black")
suggestion_label.grid(row=1, column=0, sticky="w")

suggestion_text = scrolledtext.ScrolledText(frame, width=40, height=5, wrap=tk.WORD, font=("Arial", 12))
suggestion_text.grid(row=1, column=1)

evaluate_button = tk.Button(frame, text="Check Spelling", command=evaluate_expression, font=("Arial", 12), fg="green")
evaluate_button.grid(row=2, column=0, columnspan=2, pady=10)

add_button = tk.Button(frame, text="Add to Dictionary", command=add_to_dictionary, font=("Arial", 12), fg="blue")
add_button.grid(row=3, column=0, pady=5)

quit_button = tk.Button(frame, text="Quit", command=root.quit, font=("Arial", 12), fg="red")
quit_button.grid(row=3, column=1, pady=5)

root.mainloop()
